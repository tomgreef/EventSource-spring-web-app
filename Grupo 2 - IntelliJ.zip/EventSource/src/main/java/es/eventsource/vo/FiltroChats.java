package es.eventsource.vo;

public class FiltroChats {

    private String nombre;

    public FiltroChats() {
        this.nombre = "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


}
