package es.eventsource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventSourceApplicationTests {

    @Test
    void contextLoads() {
    }

}
